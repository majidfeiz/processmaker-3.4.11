<?php

return [
    'pm' => [
        'clientId' => 'x-pm-local-client',
        'clientSecret' => '179ad45c6ce2cb97cf1029e212046e81',
        'clientName' => 'PM Web Designer',
        'clientDescription' => 'ProcessMaker Web Designer App',
        'clientWebsite' => 'www.processmaker.com',
    ],
    'mobile' => [
        'clientId' => 'x-pm-mobile-client',
        'clientSecret' => '4426746995afa07e7485df1055471800',
        'clientName' => 'PM Mobile App',
        'clientDescription' => 'PM Mobile App for Android and iOS',
        'clientWebsite' => 'www.processmaker.com',
    ],
];

<?php

return [
    'validation' => [
        'pmVariable' => [
            'regEx' => '/^[a-zA-Z\_]{1}\w+$/'
        ]
    ]
];


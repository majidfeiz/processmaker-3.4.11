translationJS ={"test":"ghsd","new":"Alert!!!!","new23":"Alert's","EDIT_PROCESS":"<u>E<\/u>dit process"};

var translationJS = 'abc';

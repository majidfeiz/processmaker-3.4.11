<?php

/**
 * Maintained for compatibility reasons.
 * @deprecated 3.2.2, File maintained only for backward compatibility because it is used in plugins
 */

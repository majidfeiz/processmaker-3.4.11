<?php
class LanguagePeer extends BaseLanguagePeer
{
}


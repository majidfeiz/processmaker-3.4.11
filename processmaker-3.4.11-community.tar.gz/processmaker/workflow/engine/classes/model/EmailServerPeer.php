<?php
class EmailServerPeer extends BaseEmailServerPeer
{
}


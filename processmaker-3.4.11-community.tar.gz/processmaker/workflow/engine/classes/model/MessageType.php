<?php
class MessageType extends BaseMessageType
{
}


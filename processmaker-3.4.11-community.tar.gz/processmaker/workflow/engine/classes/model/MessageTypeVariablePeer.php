<?php
class MessageTypeVariablePeer extends BaseMessageTypeVariablePeer
{
}


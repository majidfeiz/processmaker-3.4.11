<?php
class ScriptTaskPeer extends BaseScriptTaskPeer
{
}


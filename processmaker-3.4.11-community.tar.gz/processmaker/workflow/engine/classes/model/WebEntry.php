<?php
class WebEntry extends BaseWebEntry
{
    //
}


<?php
class TimerEventPeer extends BaseTimerEventPeer
{
}


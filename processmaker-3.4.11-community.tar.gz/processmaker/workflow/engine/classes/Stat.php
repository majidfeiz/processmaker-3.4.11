<?php

class Stat
{
    public $stutus;

    public function __construct()
    {
        $this->status = false;
    }
}

<?php

/**
 * Phing Class Wrapper
 *
 */
class PmPhing extends Phing
{
    public function getPhingVersion()
    {
        return 'pmPhing Ver 1.0';
    }
}

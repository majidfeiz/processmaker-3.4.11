<?php

interface IDynaformEditorAjax
{

}
<?php

class ToolBar extends Form
{
    public $type = 'toolbar';
    public $align = 'left';
}

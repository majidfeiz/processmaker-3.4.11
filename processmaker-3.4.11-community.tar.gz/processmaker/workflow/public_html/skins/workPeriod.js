
function abc( panel, txt ) {
/*  commonDialog ( '', 'saved' , 'saved', {}, '' )  ;
  setTimeout ( leimnud.closure({instance:myDialog,method:function(panel){
  	
  	myDialog.remove();
  	panel.tabLastSelected=false;
  	panel.tabSelected=1;
  	panel.makeTab();  
  },args:panel}) , 1000 );
*/
		var img = document.getElementById( 'workPeriodGraph' );
		img.src = 'workPeriodGraph?b=' + Math.random() ;

//  panel.clearContent();
//  panel.addContent ( txt );  
  return false;
}

  	